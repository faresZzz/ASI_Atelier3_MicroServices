
//Jquery


var use = document.getElementById("username").innerHTML
use = "a"
