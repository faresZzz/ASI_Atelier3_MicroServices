monlocalstorage = localStorage;


function SendUser() 
{
	
	if (document.getElementById("userPassword_input").value == document.getElementById("userConfirm_password_input").value){
		

	    json_obj=JSON.stringify({
	        name: document.getElementById("userName_input").value,
	        surname: document.getElementById("userSurname_input").value,
	        passwd: document.getElementById("userPassword_input").value,
		
		});
	    
	
	    fetch("http://localhost:3082/signIn", {
	        method: 'POST',
	        headers: {
	            'Accept': 'application/json',
	            'Content-Type': 'application/json'
	          },
	        body: json_obj
	    })
		.then(function(reponse) {
			if (!reponse.ok) {
				throw new Error(`erreur HTTP! statut: ${reponse.status}`);
	  		}
			return reponse.json();
			})
		.then(function(reponse) {
				localStorage.setItem('iDuser', reponse);
				var cat = localStorage.getItem('iDuser');
				console.log(cat)
				window.location.replace("/menu.html?"+reponse);
				
			} )
			.catch(error => console.log(error));
	  }
	else{
		console.log("les mdp ne correspondent pas")
	}
	
}

function send_log() 
{
    json_obj=JSON.stringify({
        surname: document.getElementById("userSurname_input").value,
        passwd: document.getElementById("userPassword_input").value
	});
        

    fetch("http://localhost:3082/login", {
    	method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
          },
        body: json_obj
    })
	.then(function(reponse) {
		if (!reponse.ok) {
			throw new Error(`erreur HTTP! statut: ${reponse.status}`);
  		}
		return reponse.json();
		})
	.then(function(reponse) {
			window.location.replace("/menu.html?"+reponse);
		} )
		.catch(error => console.log(error));
    
    

}