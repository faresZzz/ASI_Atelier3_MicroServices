$('.ui.dropdown')
  .dropdown()
;