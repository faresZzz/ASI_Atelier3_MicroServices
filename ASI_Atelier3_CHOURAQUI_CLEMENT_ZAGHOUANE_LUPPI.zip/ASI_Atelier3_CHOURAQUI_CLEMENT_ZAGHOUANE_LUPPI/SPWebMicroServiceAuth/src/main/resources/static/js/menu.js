
var idUser = localStorage.getItem('iDuser');

fetch("http://127.0.0.1:3081/user/getUserById/" + idUser, {
    method: 'GET',
    headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Origin': 'Access-Control-Allow-Origin: *'
      }
})
.then(reponse => reponse.json)
.then(reponse =>{
	document.getElementById("nom").innerHTML = reponse.name;
})