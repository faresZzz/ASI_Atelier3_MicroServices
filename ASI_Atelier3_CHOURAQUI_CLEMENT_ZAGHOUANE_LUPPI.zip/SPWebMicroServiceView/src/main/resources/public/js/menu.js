
function market(action)
{
  localStorage.setItem("action", action)
  window.location = "market.html"
}