package com.model;

import java.util.List;

public class ListCardDtoWrapper {
	
	private List<CardDto> listCard;
	
	
	public List<CardDto> getListCard() {
		return listCard;
	}

	public void setListCard(List<CardDto> listCard) {
		this.listCard = listCard;
	}

}
