$('.ui.dropdown')
  .dropdown()
;